var monkey, monkey_running
var banana, bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup, bananaGroup
var score
var player, player_running

function preload() {


  monkey_running = loadAnimation("sprite_0.png", "sprite_1.png", "sprite_2.png", "sprite_3.png", "sprite_4.png", "sprite_5.png", "sprite_6.png", "sprite_7.png", "sprite_8.png")

  bananaImage = loadImage("banana.png");
  obstaceImage = loadImage("obstacle.png");
  monkeyImage = loadImage("sprite_0.png");

  player_running = loadImage("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");

  backgroundImage = loadImage("jungle.jpg")
  
  
  
}



function setup() {

  background = createSprite(0);
  background.addImage(backgroundImage);
  background.scale = 1.5


  monkey = createSprite(50, 305, 20, 20);
  monkey.addImage(monkeyImage);
  monkey.scale = 0.15;
  monkey.addAnimation(monkey_running)


  ground = createSprite(100, 350, 900, 5);
  invisibleGround = createSprite(100, 350, 900, 5);
  invisibleGround.visible = false;
  ground.x = ground.width /2;

  banana = createSprite(290, 190, 20, 20);
  banana.addImage(bananaImage);
  banana.scale = 0.15;

  obstace = createSprite(270, 305, 20, 20)
  obstace.addImage(obstaceImage);
  obstace.scale = 0.15;

  

}



function draw() {
  
if (keyDown("space") && monkey.y >= 100) {
    monkey.velocityY = -12;
  }
    monkey.velocityY = monkey.velocityY + 0.1
  





  drawSprites();
}